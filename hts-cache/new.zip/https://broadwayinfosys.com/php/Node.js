<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8" />
<meta http-equiv="refresh" content="0;url=https://broadwayinfosys.com/php" />
<title>Redirecting to https://broadwayinfosys.com/php</title>
</head>
<body>
Redirecting to <a href="https://broadwayinfosys.com/php">https://broadwayinfosys.com/php</a>.
</body>
</html>
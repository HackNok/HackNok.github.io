<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8" />
<meta http-equiv="refresh" content="0;url=https://broadwayinfosys.com" />
<title>Redirecting to https://broadwayinfosys.com</title>
</head>
<body>
Redirecting to <a href="https://broadwayinfosys.com">https://broadwayinfosys.com</a>.
</body>
</html>
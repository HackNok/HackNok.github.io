<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8" />
<meta http-equiv="refresh" content="0;url=https://broadwayinfosys.com/404" />
<title>Redirecting to https://broadwayinfosys.com/404</title>
</head>
<body>
Redirecting to <a href="https://broadwayinfosys.com/404">https://broadwayinfosys.com/404</a>.
</body>
</html>
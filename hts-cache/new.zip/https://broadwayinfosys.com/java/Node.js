<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8" />
<meta http-equiv="refresh" content="0;url=https://broadwayinfosys.com/java" />
<title>Redirecting to https://broadwayinfosys.com/java</title>
</head>
<body>
Redirecting to <a href="https://broadwayinfosys.com/java">https://broadwayinfosys.com/java</a>.
</body>
</html>
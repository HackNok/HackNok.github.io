<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8" />
<meta http-equiv="refresh" content="0;url=https://broadwayinfosys.com/python" />
<title>Redirecting to https://broadwayinfosys.com/python</title>
</head>
<body>
Redirecting to <a href="https://broadwayinfosys.com/python">https://broadwayinfosys.com/python</a>.
</body>
</html>
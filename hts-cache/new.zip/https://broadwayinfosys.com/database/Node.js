<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8" />
<meta http-equiv="refresh" content="0;url=https://broadwayinfosys.com/database" />
<title>Redirecting to https://broadwayinfosys.com/database</title>
</head>
<body>
Redirecting to <a href="https://broadwayinfosys.com/database">https://broadwayinfosys.com/database</a>.
</body>
</html>